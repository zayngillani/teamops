// Configure your import map in config/importmap.rb. Read more: https://github.com/rails/importmap-rails
import "@hotwired/turbo-rails"
import "controllers"

document.addEventListener("turbo:load", function() {
    var startTime; // Define startTime based on the provided created_at timestamp

    // Get the created_at timestamp from the data attribute of the timerDisplay element
    var createdAt = document.getElementById("timerDisplay").dataset.createdAt;
    if (createdAt) {
        // Parse the createdAt timestamp to get the start time in milliseconds
        startTime = new Date(createdAt).getTime();
        startTimer(startTime); // Start the timer
    }

    function startTimer(startTime) {
        var timerDisplay = document.getElementById("timerDisplay");
        var systemTime = document.getElementById("timerDisplay").dataset.systemTime;
        if (systemTime) {
            // Parse the createdAt timestamp to get the start time in milliseconds
            systemTime = new Date(systemTime).getTime();
        }
        // Update the timer display every second
        var elapsedTime = systemTime - startTime; // Calculate elapsed time
        var hours = Math.floor(elapsedTime / (1000 * 60 * 60));
        var minutes = Math.floor((elapsedTime % (1000 * 60 * 60)) / (1000 * 60));
        var seconds = Math.floor((elapsedTime % (1000 * 60)) / 1000);

        // Display the elapsed time in the timerDisplay element
        timerDisplay.textContent = hours + " hours " + minutes + " minutes " + seconds + " seconds";
    }
});

document.addEventListener('turbo:load', function() {
    const flashMessage = document.getElementById('banner');
    flashMessage.classList.add('fading-out');
    setTimeout(function() {
      flashMessage.parentNode.removeChild(flashMessage);
    }, 3000);
  });

  document.addEventListener('DOMContentLoaded', function() {
    // Function to open a modal
    function openModal(modalId) {
        var modal = document.getElementById(modalId);
        modal.style.display = "block";
    }

    // Function to close a modal
    function closeModal(modalId) {
        var modal = document.getElementById(modalId);
        modal.style.display = "none";
    }

    // Event delegation for modal buttons
    document.addEventListener('click', function(event) {
        if (event.target.classList.contains('modal-btn')) {
            var targetId = event.target.getAttribute("data-target");
            openModal(targetId);
        }
    });

    // Event delegation for closing modal
    document.addEventListener('click', function(event) {
        if (event.target.classList.contains('closeModalBtn')) {
            var modal = event.target.closest(".modal");
            closeModal(modal.id);
        }
    });

    // Event delegation for closing modal when clicking outside the modal
    window.addEventListener('click', function(event) {
        if (event.target.classList.contains('modal')) {
            closeModal(event.target.id);
        }
    });

    // Event delegation for action buttons
    document.addEventListener('click', function(event) {
        if (event.target.classList.contains('sign-out-button') && event.target.classList.contains('delete-btn')) {
            var modal = event.target.closest(".modal");
            closeModal(modal.id);
            performActionAndReload();
        }
    });

    // Function to perform action and reload the page
    function performActionAndReload() {
        setTimeout(function() {
            location.reload();
        }, 1000);
    }
    
});

document.addEventListener("turbolinks:load", function() {
    const togglePasswordButtons = document.querySelectorAll(".toggle-password");
  
    togglePasswordButtons.forEach(button => {
      button.addEventListener("click", function() {
        const passwordInput = this.parentNode.querySelector(".password-input");
        if (passwordInput.type === "password") {
          passwordInput.type = "text";
          this.innerHTML = '<i class="fas fa-eye-slash"></i>'; // Change button content to "Hide" icon
        } else {
          passwordInput.type = "password";
          this.innerHTML = '<i class="fas fa-eye"></i>'; // Change button content to "Show" icon
        }
      });
    });
  });
